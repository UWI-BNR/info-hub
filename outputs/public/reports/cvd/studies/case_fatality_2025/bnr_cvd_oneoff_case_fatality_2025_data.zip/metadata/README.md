# BNR case-fatality dataset, 2010-2025

This package accompanies the BNR report *Thirty-day case fatality after cardiovascular events, Barbados, 2010-2025*.

## Files

- `data/case_fatality_2025_metrics.csv`: portable data file.
- `data/case_fatality_2025_metrics.dta`: the same data with Stata labels and notes.
- `metadata/case_fatality_2025_metadata.yml`: complete structured metadata and data dictionary.

## Which result should I use?

Use `primary_30d` as the main case-fatality measure. It counts an all-cause death within 30 days when it is identified by deterministic linkage to the all-deaths register or by a valid hospital death record.

`linked_30d` and `in_hospital_30d` are condition-specific secondary measures. They are supplied for analysis but were not presented in the initial PDF report.

## Reading the data

Annual primary results are available for CVD, Heart and Stroke, separately for women, men and both sexes. Secondary results are pooled across pre-specified reporting eras and are provided for Heart and Stroke with both sexes combined.

Crude percentages are the main descriptive results. Age-standardised percentages support comparisons over time within the same CVD, Heart or Stroke series; they should not be directly compared between those three series.

## Protected and unavailable values

Rows remain in the dataset when values cannot be shown. Check `release_status`: blank values indicate either small-count protection or a source-quality decision, not zero. The `quality_flag` field identifies an applicable data-quality caution.

## Important cohort note

All CVD pools the Heart and Stroke condition-specific cohorts. A person can contribute one index event per year to each condition cohort, and one later death can therefore contribute to both series. All CVD is an event total, not a count of distinct people or deaths.
