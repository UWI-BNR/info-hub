/*******************************************************************************
DO-FILE:     bnr_cvd_prepare_confidential.do
VERSION:     1.0.0 (21 July 2026)
PROJECT:     BNR Refit Phase 2
WORKFLOW:    Step 2 - prepare the confidential cumulative CVD dataset

PURPOSE:     Harmonise one explicitly selected post-2023 cumulative REDCap
             release, append it to the frozen 2009-2023 dataset, create the
             common analytical variables, and save one confidential dataset.

USAGE:       do "scripts/stata/monthly/bnr_cvd_prepare_confidential.do" 2024 3

INPUTS:      $BNR_DATA_FROZEN/releases/y2023/m12/
                 bnr-cvd-indiv-full-202312-v01.dta

             $BNR_DATA_RAW/redcap/cvd/yYYYY/mMM/
                 bnr_cvd_redcap_raw_YYYYMM.dta

OUTPUTS:     $BNR_DATA_DERIVED/cvd/yYYYY/mMM/
                 bnr_cvd_confidential_YYYYMM_v01.dta
                 bnr_cvd_confidential_YYYYMM_v01.yml

             $BNR_PRIVATE_LOGS/
                 bnr_cvd_prepare_confidential_YYYYMM.log

SECURITY:    Every input and output is confidential and remains outside Git.
             This DO-file does not create metric inputs, staging packages,
             public files, or website files.

IMPORTANT:   The selected post-2023 extract currently contains abstracted
             cases only. DCO cases are not yet available. When the new DCO
             source is introduced, validate and combine it with the selected
             post-2023 release before the append performed here.
*******************************************************************************/

version 19
clear all
set more off

* -----------------------------------------------------------------------------
* 0. Arguments and local paths
* -----------------------------------------------------------------------------

args release_year release_month

if "`release_year'" == "" | "`release_month'" == "" {
    display as error "Release year and month are required."
    display as error ///
        "Example: do scripts/stata/monthly/bnr_cvd_prepare_confidential.do 2024 3"
    exit 198
}

if `"$BNR_STATA"' == "" {
    capture noisily do ///
        "C:/yoshimi-hot/output/analyse-bnr/info-hub/scripts/stata/config/bnr_paths_LOCAL.do"
    if _rc {
        local config_rc = _rc
        display as error "The BNR local path configuration could not be loaded."
        exit `config_rc'
    }
}

do "$BNR_STATA/common/bnrcvd_globals.do"

local year_num  = real("`release_year'")
local month_num = real("`release_month'")

if missing(`year_num') | `year_num' != floor(`year_num') | `year_num' < 2024 {
    display as error "Release year must be an integer of 2024 or later."
    exit 198
}

if missing(`month_num') | `month_num' != floor(`month_num') | ///
        !inrange(`month_num', 1, 12) {
    display as error "Release month must be an integer from 1 to 12."
    exit 198
}

local year4  : display %04.0f `year_num'
local month2 : display %02.0f `month_num'
local period "`year4'`month2'"

if `month_num' == 12 {
    local end_td = mdy(12, 31, `year_num')
}
else {
    local end_td = mdy(`month_num' + 1, 1, `year_num') - 1
}

local start_td = mdy(1, 1, 2024)
local end_date : display %tdCCYY-NN-DD `end_td'

local historical_file ///
    "$BNR_DATA_FROZEN/releases/y2023/m12/bnr-cvd-indiv-full-202312-v01.dta"
local release_file ///
    "$BNR_DATA_RAW/redcap/cvd/y`year4'/m`month2'/bnr_cvd_redcap_raw_`period'.dta"

local output_root  "$BNR_DATA_DERIVED/cvd"
local output_year  "`output_root'/y`year4'"
local output_dir   "`output_year'/m`month2'"
local output_id    "bnr_cvd_confidential_`period'_v01"
local output_dta   "`output_dir'/`output_id'.dta"
local output_yml   "`output_dir'/`output_id'.yml"
local output_log   "$BNR_PRIVATE_LOGS/bnr_cvd_prepare_confidential_`period'.log"

foreach required_file in "`historical_file'" "`release_file'" {
    capture confirm file "`required_file'"
    if _rc {
        display as error "Required input not found:"
        display as error "  `required_file'"
        exit 601
    }
}

capture mkdir "$BNR_DATA_DERIVED"
capture mkdir "`output_root'"
capture mkdir "`output_year'"
capture mkdir "`output_dir'"
capture mkdir "$BNR_PRIVATE_LOGS"

capture log close step1
log using "`output_log'", text replace name(step1)

display as text "BNR CVD STEP 1: CONFIDENTIAL CUMULATIVE DATASET"
display as result "  Script version: 1.0.0"
display as result "  Selected release: `year4'-`month2'"
display as result "  Historical input: `historical_file'"
display as result "  Post-2023 input:  `release_file'"
display as result "  Private output:   `output_dta'"

* -----------------------------------------------------------------------------
* 1. Validate and harmonise the selected post-2023 release
* -----------------------------------------------------------------------------

tempfile post2023
use "`release_file'", clear

quietly count
local n_post = r(N)
quietly ds
local k_post : word count `r(varlist)'

local core_fields recid redcap_event_name edate dob cfage natregno recnum
foreach variable of local core_fields {
    capture confirm string variable `variable'
    if _rc {
        display as error ///
            "Post-2023 schema failure: `variable' is absent or is not a string."
        log close step1
        exit 109
    }
}

quietly count if inlist(strtrim(recid), "", ".")
local missing_recid = r(N)
quietly count if inlist(strtrim(redcap_event_name), "", ".")
local missing_event = r(N)
quietly count if inlist(strtrim(edate), "", ".", "99")
local missing_edate = r(N)
quietly count if redcap_event_name == "stroke_arm_1"
local n_stroke = r(N)
quietly count if redcap_event_name == "heart_arm_2"
local n_ami = r(N)

tempvar duplicate_id
quietly duplicates tag recid redcap_event_name, generate(`duplicate_id')
quietly count if `duplicate_id' > 0
local duplicate_rows = r(N)
drop `duplicate_id'

if `missing_recid' | `missing_event' | `missing_edate' | `duplicate_rows' {
    display as error "The selected release is not structurally safe to append."
    display as error "  Missing recid:              `missing_recid'"
    display as error "  Missing REDCap event:       `missing_event'"
    display as error "  Missing event date:         `missing_edate'"
    display as error "  Duplicate recid/event rows: `duplicate_rows'"
    log close step1
    exit 459
}

* REDCap fields imported by Step 0 as strings but analytically numeric.
local numeric_fields ///
    cfsource___1 cfsource___2 cfsource___3 cfsource___4 cfsource___5 ///
    cfsource___6 cfsource___7 cfsource___8 cfsource___9 cfsource___10 ///
    cfsource___11 cfsource___12 cfsource___13 cfsource___14 ///
    cfsource___15 cfsource___16 cfsource___17 cfsource___18 ///
    cfsource___19 cfsource___20 cfsource___21 cfsource___22 ///
    cfsource___23 cfsource___24 cfsource___25 cfsource___26 ///
    cfsource___27 sex cfage cfage_da hstatus slc cstatus eligible ///
    ineligible duplicate duprec dupcheck toabs mstatus resident citizen ///
    parish ward___1 ward___2 ward___3 ward___4 ward___5 htype stype ///
    dxtype dstroke inhosp etimeampm pstroke pstrokeyr pami pamiyr ///
    rfany htn diab sysbp diasbp bgunit bgmg bgmmol dieany_2 decg ecg ///
    ecgtampm tropdone troptype tropres trop1res trop2res assess assess1 ///
    assess2 assess3 assess4 dieany dct ct reperf repertype asp___1 ///
    asp___2 asp___3 aspdose asptimeampm_2 vstatus dismeds___1 ///
    dismeds___2 dismeds___3 dismeds___4 dismeds___5 dismeds___6 ///
    dismeds___7 dismeds___8 dismeds___9 dismeds___10 aspdosedis ///
    dissysbp disdiasbp disbgmmol carunit strunit sunitadmsame ///
    sunitdissame ward___88 ward___99 ward___999 ward___9999 ///
    casefinding_demographics_complet edateyr edatemon edatemondash ///
    event_complete tests_complete asp___88 asp___99 asp___999 ///
    asp___9999 dismeds___88 dismeds___99 dismeds___999 ///
    dismeds___9999 treatment_discharge_complete

local conversion_failures 0
foreach variable of local numeric_fields {
    capture confirm string variable `variable'
    if _rc {
        display as error "Expected post-2023 numeric field is absent: `variable'"
        local ++conversion_failures
    }
    else {
        quietly count if !inlist(strtrim(`variable'), "", ".") & ///
            missing(real(strtrim(`variable')))
        if r(N) {
            display as error ///
                "`variable': " r(N) " value(s) cannot be converted to numeric."
            local conversion_failures = `conversion_failures' + r(N)
        }
    }
}

if `conversion_failures' {
    display as error ///
        "Post-2023 numeric conversion failed; the output was not created."
    log close step1
    exit 459
}

foreach variable of local numeric_fields {
    quietly replace `variable' = "" if strtrim(`variable') == "."
    quietly destring `variable', replace
}

* Blank, string ".", and string "99" are ordinary missing dates in the
* post-2023 extract. Any other unparseable value is a conversion failure.
local date_fields ///
    cfdoa dob cfadmdate dlc cfdod edate ecgd doct reperfd aspd ///
    astrunitd dstrunitd

local date_failures 0
foreach variable of local date_fields {
    capture confirm string variable `variable'
    if _rc {
        display as error "Expected post-2023 date field is absent: `variable'"
        local ++date_failures
    }
    else {
        tempvar parsed_date
        quietly generate double `parsed_date' = daily(strtrim(`variable'), "YMD")
        quietly replace `parsed_date' = daily(strtrim(`variable'), "DMY") ///
            if missing(`parsed_date') & ///
            !inlist(strtrim(`variable'), "", ".", "99")
        quietly count if !inlist(strtrim(`variable'), "", ".", "99") & ///
            missing(`parsed_date')
        if r(N) {
            display as error ///
                "`variable': " r(N) " value(s) cannot be converted to a date."
            local date_failures = `date_failures' + r(N)
        }
        drop `variable'
        rename `parsed_date' `variable'
        format `variable' %tdCCYY-NN-DD
    }
}

if `date_failures' {
    display as error ///
        "Post-2023 date conversion failed; the output was not created."
    log close step1
    exit 459
}

quietly count if !inrange(edate, `start_td', `end_td')
local event_dates_outside = r(N)
if `event_dates_outside' {
    display as error ///
        "`event_dates_outside' event date(s) fall outside the selected cumulative period."
    log close step1
    exit 459
}

quietly summarize edate
local min_event : display %tdCCYY-NN-DD r(min)
local max_event : display %tdCCYY-NN-DD r(max)

generate byte source_era = 1
generate long source_release = `period'
label define source_era_ 0 "Frozen 2009-2023" 1 "Post-2023 REDCap", replace
label values source_era source_era_
label variable source_release "Selected source release (YYYYMM)"

save `post2023', replace

* -----------------------------------------------------------------------------
* 2. Load the invariant historical dataset and append the selected release
* -----------------------------------------------------------------------------

use "`historical_file'", clear
quietly count
local n_historical = r(N)
quietly ds
local k_historical : word count `r(varlist)'

if `n_historical' != 16306 | `k_historical' != 145 {
    display as error "The invariant 2009-2023 source does not match its contract."
    display as error "  Expected: 16,306 records and 145 fields"
    display as error "  Found:    `n_historical' records and `k_historical' fields"
    log close step1
    exit 459
}

generate byte source_era = 0
generate long source_release = 202312
label define source_era_ 0 "Frozen 2009-2023" 1 "Post-2023 REDCap", replace
label values source_era source_era_
label variable source_release "Selected source release (YYYYMM)"

append using `post2023'

quietly count
local n_total = r(N)
local expected_total = `n_historical' + `n_post'
if `n_total' != `expected_total' {
    display as error "Record-count failure after append."
    log close step1
    exit 459
}

* -----------------------------------------------------------------------------
* 3. Common analytical variables - no records are excluded
* -----------------------------------------------------------------------------

* Stable event identifier. Historical IDs retain the approved pid; later IDs
* use the REDCap record and event. Prefixes prevent cross-era collisions.
generate str32 eid = "H" + strofreal(pid, "%09.0f") if source_era == 0
replace eid = "R" + strtrim(recid) + "_" + redcap_event_name ///
    if source_era == 1
label variable eid "CVD event unique identifier"

quietly isid eid

clonevar rid = recid
label variable rid "REDCap record ID"

generate byte dco_alt = 0
replace dco_alt = 2 if source_era == 0 & sd_absstatus == 2
replace dco_alt = 1 if source_era == 0 & sd_absstatus == 3

generate byte dco = 0
replace dco = 1 if source_era == 0 & sd_absstatus == 3

label define dco_alt_ 0 "Abstracted" 1 "DCO" 2 "Partial abstraction", replace
label define dco_ 0 "Abstracted" 1 "DCO", replace
label values dco_alt dco_alt_
label values dco dco_
label variable dco_alt "Abstraction status"
label variable dco "Death-certificate-only case"
note dco: Post-2023 releases currently contain abstracted cases only; DCO surveillance is not yet included.

generate byte etype = 1 if redcap_event_name == "stroke_arm_1"
replace etype = 2 if redcap_event_name == "heart_arm_2"
label define etype_ 1 "Stroke" 2 "AMI", replace
label values etype etype_
label variable etype "CVD event type"

quietly count if missing(etype)
if r(N) {
    display as error r(N) " record(s) have an unrecognised REDCap event name."
    log close step1
    exit 459
}

* Canonical analytical dates retain the original source fields alongside them.
clonevar docf  = cfdoa
clonevar doe   = edate
clonevar doa   = cfadmdate
clonevar dodi  = dlc
clonevar dod   = cfdod
clonevar doecg = ecgd
clonevar dore  = reperfd
clonevar doasp = aspd
clonevar doasu = astrunitd
clonevar dodisu = dstrunitd

format docf doe doa dodi dod doecg dore doasp doasu dodisu %tdCCYY-NN-DD

generate int yoe = year(doe)
generate byte moe = month(doe)
label variable yoe "CVD event year"
label variable moe "CVD event month"

* Time components. The original source strings remain available for QA.
generate byte htoe = real(substr(etime, 1, 2))
generate byte mtoe = real(substr(etime, 4, 2))
generate byte htoa = real(substr(admtime, 1, 2))
generate byte mtoa = real(substr(admtime, 4, 2))
generate byte htecg = real(substr(ecgt, 1, 2))
generate byte mtecg = real(substr(ecgt, 4, 2))
generate byte htore = real(substr(reperft, 1, 2))
generate byte mtore = real(substr(reperft, 4, 2))
generate byte htoasp = real(substr(aspt, 1, 2))
generate byte mtoasp = real(substr(aspt, 4, 2))

* Period-specific approved age rules.
generate int agey = floor(cfage) if source_era == 0
replace agey = age(dob, doe) if source_era == 1 & !missing(dob, doe)
label variable agey "Age at event in completed years"
note agey: Through 2023, floor(cfage); from 2024, calculated from dob and event date.

quietly count if source_era == 1 & missing(agey)
local missing_age_post = r(N)
quietly count if !missing(agey) & !inrange(agey, 0, 120)
if r(N) {
    display as error r(N) " implausible calculated age(s) detected."
    log close step1
    exit 459
}

recode agey ///
    (0/4=1) (5/9=2) (10/14=3) (15/19=4) (20/24=5) ///
    (25/29=6) (30/34=7) (35/39=8) (40/44=9) (45/49=10) ///
    (50/54=11) (55/59=12) (60/64=13) (65/69=14) ///
    (70/74=15) (75/79=16) (80/84=17) (85/120=18), generate(age5)

label define age5_ ///
    1 "0-4" 2 "5-9" 3 "10-14" 4 "15-19" 5 "20-24" ///
    6 "25-29" 7 "30-34" 8 "35-39" 9 "40-44" 10 "45-49" ///
    11 "50-54" 12 "55-59" 13 "60-64" 14 "65-69" ///
    15 "70-74" 16 "75-79" 17 "80-84" 18 "85+", replace
label values age5 age5_
label variable age5 "Age at event in 5-year groups"

generate byte age70 = agey >= 70 if !missing(agey)
label define age70_ 0 "Under 70 years" 1 "70 years and older", replace
label values age70 age70_
label variable age70 "Age at event: under 70 or 70+"

* Frequently used canonical aliases. Source fields are retained to keep Step 1
* lossless and to support future metric-input definitions in Step 2.
clonevar sadi = vstatus
clonevar sbp = sysbp
clonevar dbp = diasbp
clonevar asp1 = asp___1
clonevar asp2 = asp___2
clonevar asp3 = asp___3
clonevar asp_ampm = asptimeampm_2
clonevar aspdose_dis = aspdosedis
clonevar sunit = strunit
clonevar doasu_same = sunitadmsame
clonevar dodisu_same = sunitdissame

forvalues medication = 1/10 {
    clonevar dmed`medication' = dismeds___`medication'
}

* Keep sentinel handling consistent with the established 2023 preparation.
mvdecode sadi, mv(99=.a)
mvdecode pstroke pami htn diab ecg repertype sunit doasu_same dodisu_same, ///
    mv(99=.a)
* Retain the established historical treatment of legacy sentinel codes.
* The two .c codes are historical non-years, not valid years of a stroke.
mvdecode pstrokeyr, mv(99=.a \ 9999=.b \ 1=.c \ 1908=.c)
mvdecode pamiyr, mv(99=.a \ 9999=.b)
mvdecode sbp dbp, mv(999=.a \ 99999=.b)
* Troponin sentinel 9999.99 can arrive from the frozen historical file as a
* float, where binary rounding prevents an exact literal comparison. Decode
* it after rounding to two decimal places; clinical values are otherwise
* unchanged. Zero remains the established .a sentinel.
mvdecode trop1res trop2res, mv(0=.a)
foreach variable in trop1res trop2res {
    replace `variable' = .b if !missing(`variable') & ///
        round(`variable', .01) == 9999.99
}
mvdecode assess assess1 assess2 assess3 assess4 ct reperf, ///
    mv(99=.a \ 99999=.b)
mvdecode aspdose, mv(999=.a)
mvdecode aspdose_dis, mv(99=.a \ 999=.b)

* Parish code 99 is an explicit historical missing-value code.
recode parish (99=.)

* Identifiers remain only in this confidential Step 1 output.
clonevar id_fname = fname
clonevar id_mname = mname
clonevar id_lname = lname
clonevar id_nid = natregno
clonevar id_hid = recnum

order eid rid source_era source_release dco dco_alt etype ///
    docf dob doe yoe moe htoe mtoe doa htoa mtoa dodi sadi dod ///
    sex agey age5 age70
order id_fname id_mname id_lname id_nid id_hid, last

compress
sort doe etype eid

* -----------------------------------------------------------------------------
* 4. Final private QA, save and metadata receipt
* -----------------------------------------------------------------------------

quietly count if source_era == 0
assert r(N) == `n_historical'
quietly count if source_era == 1
assert r(N) == `n_post'
quietly count
assert r(N) == `expected_total'
quietly isid eid

preserve
keep eid etype doe source_release
sort eid
capture quietly datasignature, nonames
if _rc local data_signature "not_available"
else local data_signature "`r(datasignature)'"
restore

label data "BNR CVD confidential cumulative analytical dataset through `end_date'"
notes _dta: title: BNR CVD confidential cumulative analytical dataset
notes _dta: dataset_id: `output_id'
notes _dta: created: $todayiso
notes _dta: temporal: 2009 through `end_date'
notes _dta: tier: Confidential identifiable individual-level data
notes _dta: unit_of_analysis: One row per CVD event
notes _dta: source_historical: `historical_file'
notes _dta: source_post_2023: `release_file'
notes _dta: coverage_limitation: Post-2023 DCO cases are not yet included
notes _dta: rights: Restricted to authorised BNR use; not for public release

save "`output_dta'", replace

tempname yaml
file open `yaml' using "`output_yml'", write text replace
file write `yaml' "dataset_id: `output_id'" _n
file write `yaml' "status: confidential" _n
file write `yaml' "created: $todayiso" _n
file write `yaml' `"created_by: "`analyst'""' _n
file write `yaml' "release: `year4'-`month2'" _n
file write `yaml' "coverage_end: `end_date'" _n
file write `yaml' "records_historical: `n_historical'" _n
file write `yaml' "records_post_2023: `n_post'" _n
file write `yaml' "records_total: `n_total'" _n
file write `yaml' "records_stroke_post_2023: `n_stroke'" _n
file write `yaml' "records_ami_post_2023: `n_ami'" _n
file write `yaml' "fields_post_2023_source: `k_post'" _n
file write `yaml' "event_date_min_post_2023: `min_event'" _n
file write `yaml' "event_date_max_post_2023: `max_event'" _n
file write `yaml' "missing_age_post_2023: `missing_age_post'" _n
file write `yaml' `"data_signature_core: "`data_signature'""' _n
file write `yaml' "dco_post_2023_included: false" _n
file write `yaml' `"source_historical: "`historical_file'""' _n
file write `yaml' `"source_post_2023: "`release_file'""' _n
file close `yaml'

* -----------------------------------------------------------------------------
* 5. Single operational run summary
* -----------------------------------------------------------------------------
* Keep the end-of-run result tidy in both the Results window and private log.
* A temporary frame is used so the analyst's active data remain untouched.
local n_historical_display : display %12.0fc `n_historical'
local n_post_display : display %12.0fc `n_post'
local n_stroke_display : display %12.0fc `n_stroke'
local n_ami_display : display %12.0fc `n_ami'
local n_total_display : display %12.0fc `n_total'

tempname summary_frame
frame create `summary_frame'

frame `summary_frame': quietly set obs 15
frame `summary_frame': generate str24 operational_item = ""
frame `summary_frame': generate strL result = ""

frame `summary_frame': replace operational_item = "Run status" in 1
frame `summary_frame': replace result = "Completed successfully" in 1
frame `summary_frame': replace operational_item = "Script version" in 2
frame `summary_frame': replace result = "1.0.0" in 2
frame `summary_frame': replace operational_item = "Selected release" in 3
frame `summary_frame': replace result = "`year4'-`month2'" in 3
frame `summary_frame': replace operational_item = "Historical records" in 4
frame `summary_frame': replace result = "`n_historical_display'" in 4
frame `summary_frame': replace operational_item = "Post-2023 records" in 5
frame `summary_frame': replace result = "`n_post_display'" in 5
frame `summary_frame': replace operational_item = "Post-2023 stroke" in 6
frame `summary_frame': replace result = "`n_stroke_display'" in 6
frame `summary_frame': replace operational_item = "Post-2023 AMI" in 7
frame `summary_frame': replace result = "`n_ami_display'" in 7
frame `summary_frame': replace operational_item = "Total records" in 8
frame `summary_frame': replace result = "`n_total_display'" in 8
frame `summary_frame': replace operational_item = "Post-2023 dates" in 9
frame `summary_frame': replace result = "`min_event' through `max_event'" in 9
frame `summary_frame': replace operational_item = "Missing post-2023 age" in 10
frame `summary_frame': replace result = "`missing_age_post'" in 10
frame `summary_frame': replace operational_item = "DCO limitation" in 11
frame `summary_frame': replace result = ///
    "Post-2023 DCO records are not yet included." in 11
frame `summary_frame': replace operational_item = "Private dataset" in 12
frame `summary_frame': replace result = `"`output_dta'"' in 12
frame `summary_frame': replace operational_item = "YAML receipt" in 13
frame `summary_frame': replace result = `"`output_yml'"' in 13
frame `summary_frame': replace operational_item = "Private log" in 14
frame `summary_frame': replace result = `"`output_log'"' in 14
frame `summary_frame': replace operational_item = "Next step" in 15
frame `summary_frame': replace result = ///
    "Create the required deidentified metric-input datasets (Step 3)." in 15

frame `summary_frame': label variable operational_item "Operational item"
frame `summary_frame': label variable result "Result"
frame `summary_frame': format operational_item %-24s
frame `summary_frame': format result %-180s

local original_linesize = c(linesize)
set linesize 220
display as text ""
display as text "BNR CVD Step 2: operational run summary"
frame `summary_frame': list operational_item result, noobs clean abbreviate(24)
set linesize `original_linesize'

frame drop `summary_frame'

log close step1
