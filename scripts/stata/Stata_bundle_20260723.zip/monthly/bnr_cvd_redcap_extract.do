/*******************************************************************************
DO-FILE:     bnr_cvd_redcap_extract.do
PROJECT:     BNR Refit Phase 2
PURPOSE:     Step 1 of the monthly CVD workflow. Extract a private cumulative
             REDCap snapshot from 1 January 2024 through a selected month-end.

USAGE:       Run from the info-hub repository root:

                 do "scripts/stata/monthly/bnr_cvd_redcap_extract.do" 2024 1

             If an extract for that month already exists, add replace:

                 do "scripts/stata/monthly/bnr_cvd_redcap_extract.do" 2024 1 replace

             The optional dialog constructs exactly the same command. It does
             not use a separate extraction pathway.

SECURITY:    The REDCap API token is read directly by Python from the local
             text file identified by $BNR_REDCAP_TOKEN_FILE. The token must
             never be written in this DO file, stored in a Stata macro, printed
             to a log, or committed to Git.

INPUT:       REDCap API: https://caribdata.org/redcap/api/
FILTER:      2024-01-01 <= edate <= final day of selected month
OUTPUT:      Private raw CSV, Stata dataset, YAML manifest and Stata log under:
             $BNR_DATA_RAW/redcap/cvd/yYYYY/mMM/

NOTES:       This is a private source-data extract. It deliberately retains
             identifiers and operational fields. De-identification belongs in
             Step 2 of the monthly workflow.
*******************************************************************************/

version 19
set more off

* -----------------------------------------------------------------------------
* 0. Read arguments and load local paths
* -----------------------------------------------------------------------------

args release_year release_month replace_existing

if "`release_year'" == "" | "`release_month'" == "" {
    display as error "Year and month are required."
    display as error ///
        "Example: do scripts/stata/monthly/bnr_cvd_redcap_extract.do 2024 1"
    exit 198
}

* If the BNR configuration has already been loaded, retain it. Otherwise use
* this workstation's bootstrap path. This keeps the established CLI command
* unchanged and also lets the dialog call the same DO file.
if `"$BNR_STATA"' == "" {
    capture noisily do ///
        "C:/yoshimi-hot/output/analyse-bnr/info-hub/scripts/stata/config/bnr_paths_LOCAL.do"
    local config_rc = _rc
    if `config_rc' {
        display as error "The BNR local path configuration could not be loaded."
        display as error ///
            "Check the bootstrap path near the top of bnr_cvd_redcap_extract.do."
        exit `config_rc'
    }
}

if `"$BNR_STATA"' == "" | `"$BNR_DATA_RAW"' == "" | ///
        `"$BNR_PRIVATE_LOGS"' == "" | `"$BNR_REDCAP_TOKEN_FILE"' == "" {
    display as error "The BNR local path configuration is incomplete."
    exit 198
}

* The API URL is public configuration; the token is not.
local redcap_url "https://caribdata.org/redcap/api/"

* -----------------------------------------------------------------------------
* 1. Validate the requested release month
* -----------------------------------------------------------------------------

local year_num  = real("`release_year'")
local month_num = real("`release_month'")

if missing(`year_num') | `year_num' != floor(`year_num') | `year_num' < 2024 {
    display as error "Year must be an integer greater than or equal to 2024."
    exit 198
}

if missing(`month_num') | `month_num' != floor(`month_num') | ///
        !inrange(`month_num', 1, 12) {
    display as error "Month must be an integer from 1 to 12."
    exit 198
}

if "`replace_existing'" != "" & lower("`replace_existing'") != "replace" {
    display as error "The optional third argument must be replace."
    display as error ///
        "Example: do scripts/stata/monthly/bnr_cvd_redcap_extract.do 2024 1 replace"
    exit 198
}

local start_date "2024-01-01"

if `month_num' == 12 {
    local end_td = mdy(12, 31, `year_num')
}
else {
    local end_td = mdy(`month_num' + 1, 1, `year_num') - 1
}

local end_date : display %tdCCYY-NN-DD `end_td'
local year4    : display %04.0f `year_num'
local month2   : display %02.0f `month_num'
local period   "`year4'`month2'"

* Do not create a nominal month-end snapshot before that month has ended.
local today_td = daily("`c(current_date)'", "DMY")
if `end_td' > `today_td' {
    display as error ///
        "The selected month has not ended. Choose the latest completed month."
    exit 198
}

* -----------------------------------------------------------------------------
* 2. Define private output files
* -----------------------------------------------------------------------------

local release_dir ///
    "$BNR_DATA_RAW/redcap/cvd/y`year4'/m`month2'"
local file_stub ///
    "bnr_cvd_redcap_raw_`period'"

local outcsv      "`release_dir'/`file_stub'.csv"
local outdta      "`release_dir'/`file_stub'.dta"
local outmanifest "`release_dir'/`file_stub'_manifest.yml"
local outlog      "$BNR_PRIVATE_LOGS/`file_stub'.log"

* Prevent accidental replacement of a retained raw extract.  During
* development, use the explicit replace argument to remove the three
* associated extract files before rerunning the same month.
local existing_output 0
foreach file in "`outcsv'" "`outdta'" "`outmanifest'" {
    capture confirm file `"`file'"'
    if !_rc {
        local existing_output 1
    }
}

if `existing_output' {
    if lower("`replace_existing'") != "replace" {
        display as error "An extract already exists for `year4'-`month2'."
        display as error ///
            "To replace this development extract, rerun with the third argument replace."
        exit 602
    }

    display as text "Replacing existing extract files for `year4'-`month2'."
    foreach file in "`outcsv'" "`outdta'" "`outmanifest'" {
        capture confirm file `"`file'"'
        if !_rc {
            erase `"`file'"'
        }
    }
}

capture mkdir "$BNR_PRIVATE"
capture mkdir "$BNR_PRIVATE/logs"
capture mkdir "$BNR_PRIVATE_LOGS"
capture log close redcap_extract
log using "`outlog'", text replace name(redcap_extract)

display as text "BNR monthly REDCap extract"
display as result "  Period:    2024-01-01 through `end_date'"
display as result "  Output:    `release_dir'"

* -----------------------------------------------------------------------------
* 3. Extract raw records using PyCap
* -----------------------------------------------------------------------------

python:
from sfi import Macro
from redcap import Project

import csv
import hashlib
import io
import os
from datetime import datetime, timezone


api_url = Macro.getLocal("redcap_url")
token_file = Macro.getGlobal("BNR_REDCAP_TOKEN_FILE")
start_date = Macro.getLocal("start_date")
end_date = Macro.getLocal("end_date")
release_year = Macro.getLocal("year4")
release_month = Macro.getLocal("month2")
outcsv = Macro.getLocal("outcsv")
outmanifest = Macro.getLocal("outmanifest")

expected_events = {"stroke_arm_1", "heart_arm_2"}

# These are the fields used by the earlier post-2023 workflow. The export is
# intentionally broader, but checking this list detects an incompatible schema
# before an apparently successful raw snapshot is accepted.
required_fields = {
    "recid", "cfdoa", "fname", "mname", "lname", "sex", "dob",
    "cfage", "cfage_da", "natregno", "recnum", "cfadmdate", "admtime",
    "dlc", "cfdod", "parish", "ward___1", "ward___2", "ward___3",
    "ward___4", "ward___5", "htype", "stype", "edate", "etime",
    "pstroke", "pstrokeyr", "pami", "pamiyr", "htn", "diab", "sysbp",
    "diasbp", "bgmmol", "ecg", "ecgd", "ecgt", "tropres", "trop1res",
    "trop2res", "assess", "assess1", "assess2", "assess3", "assess4",
    "ct", "doct", "reperf", "repertype", "reperfd", "reperft",
    "asp___1", "asp___2", "asp___3", "aspdose", "aspd", "aspt",
    "asptimeampm_2", "vstatus", "dismeds___1", "dismeds___2",
    "dismeds___3", "dismeds___4", "dismeds___5", "dismeds___6",
    "dismeds___7", "dismeds___8", "dismeds___9", "dismeds___10",
    "aspdosedis", "strunit", "sunitadmsame", "astrunitd",
    "sunitdissame", "dstrunitd", "redcap_event_name"
}


def stop(message):
    """Raise a short error that cannot reveal the API token."""
    raise RuntimeError(message) from None


if not token_file:
    stop("BNR_REDCAP_TOKEN_FILE is not defined in bnr_paths_LOCAL.do.")

if not os.path.isfile(token_file):
    stop("The local REDCap token file was not found.")

with open(token_file, "r", encoding="utf-8-sig") as handle:
    api_token = handle.read().strip()

if not api_token or api_token == "PASTE_REDCAP_API_TOKEN_HERE":
    stop("The local REDCap token file does not yet contain a token.")

if any(character.isspace() for character in api_token):
    stop("The REDCap token file must contain only the token on one line.")

filter_logic = (
    f"[edate] >= '{start_date}' and [edate] <= '{end_date}'"
)

try:
    project = Project(api_url, api_token)
    csv_text = project.export_records(
        "csv",
        raw_or_label="raw",
        raw_or_label_headers="raw",
        export_checkbox_labels=False,
        filter_logic=filter_logic,
    )
except Exception as error:
    stop(
        "REDCap extraction failed "
        f"({type(error).__name__}). Check the API URL, token permissions, "
        "network connection and selected date period."
    )

if isinstance(csv_text, bytes):
    csv_text = csv_text.decode("utf-8-sig")

reader = csv.DictReader(io.StringIO(csv_text))
headers = reader.fieldnames or []
rows = list(reader)

missing_fields = sorted(required_fields.difference(headers))
if missing_fields:
    stop(
        "REDCap schema validation failed. Missing expected fields: "
        + ", ".join(missing_fields)
    )

if not rows:
    stop("The requested cumulative period returned no REDCap records.")

observed_events = {
    row.get("redcap_event_name", "").strip()
    for row in rows
    if row.get("redcap_event_name", "").strip()
}

unexpected_events = sorted(observed_events.difference(expected_events))
if unexpected_events:
    stop(
        "Unexpected REDCap event names were returned: "
        + ", ".join(unexpected_events)
    )

missing_events = sorted(expected_events.difference(observed_events))
if missing_events:
    print(
        "Warning: no rows were returned for expected event name(s): "
        + ", ".join(missing_events)
    )

os.makedirs(os.path.dirname(outcsv), exist_ok=True)

# REDCap free-text fields can contain quotation marks.  Although Python reads
# the API response correctly, Stata's CSV importer can interpret a small
# number of those rows differently and shift the remaining columns.  Write a
# normalised RFC-style CSV from the parsed rows so the file handed to Stata has
# one consistently quoted record per row.  This remains a complete private
# source extract; no fields or values are changed.
with open(outcsv, "w", encoding="utf-8", newline="") as handle:
    writer = csv.DictWriter(
        handle,
        fieldnames=headers,
        extrasaction="raise",
        quoting=csv.QUOTE_ALL,
        lineterminator="\n",
    )
    writer.writeheader()
    writer.writerows(rows)

with open(outcsv, "rb") as handle:
    csv_sha256 = hashlib.sha256(handle.read()).hexdigest()

# Write a deliberately simple YAML receipt.  No YAML package is needed: all
# values are controlled by this DO file or REDCap validation above, and text
# values are double-quoted so staff can read the file safely in any editor.
def yaml_text(value):
    return str(value).replace("\\", "\\\\").replace('"', '\\"')


with open(outmanifest, "w", encoding="utf-8", newline="\n") as handle:
    handle.write("# Private operational receipt: do not publish with patient-level data.\n")
    handle.write("package_type: private_redcap_raw_extract\n")
    handle.write('source_system: "BNR CVD REDCap"\n')
    handle.write(f'api_url: "{yaml_text(api_url)}"\n')
    handle.write(f'event_date_start: "{start_date}"\n')
    handle.write(f'event_date_end: "{end_date}"\n')
    handle.write(f"release_year: {int(release_year)}\n")
    handle.write(f"release_month: {int(release_month)}\n")
    handle.write("filter_field: edate\n")
    handle.write(f'filter_logic: "{yaml_text(filter_logic)}"\n')
    handle.write(f"record_rows: {len(rows)}\n")
    handle.write(f"field_count: {len(headers)}\n")
    handle.write("event_names:\n")
    for event_name in sorted(observed_events):
        handle.write(f'  - "{yaml_text(event_name)}"\n')
    if missing_events:
        handle.write("expected_event_names_without_rows:\n")
        for event_name in missing_events:
            handle.write(f'  - "{yaml_text(event_name)}"\n')
    else:
        handle.write("expected_event_names_without_rows: []\n")
    handle.write(f'csv_file: "{yaml_text(os.path.basename(outcsv))}"\n')
    handle.write(f'csv_sha256: "{csv_sha256}"\n')
    handle.write(f'extracted_at_utc: "{datetime.now(timezone.utc).isoformat()}"\n')
    handle.write("confidential: true\n")

print(f"REDCap returned {len(rows):,} rows and {len(headers):,} fields.")
print("The token was read locally and was not written to the Stata session.")
end

* -----------------------------------------------------------------------------
* 4. Import the raw CSV and validate it in a temporary Stata frame
* -----------------------------------------------------------------------------

confirm file "`outcsv'"
confirm file "`outmanifest'"

* The analyst's current data remain untouched. The temporary frame is removed
* automatically when this DO file finishes.
tempname extract_frame
frame create `extract_frame'

frame `extract_frame': import delimited using "`outcsv'", clear ///
    stringcols(_all) varnames(1) bindquote(strict)

frame `extract_frame': confirm variable recid edate redcap_event_name
frame `extract_frame': assert inlist(redcap_event_name, ///
    "stroke_arm_1", "heart_arm_2")

frame `extract_frame': generate double __event_date = daily(edate, "YMD")
frame `extract_frame': replace __event_date = daily(edate, "DMY") ///
    if missing(__event_date) & edate != ""
frame `extract_frame': format __event_date %tdCCYY-NN-DD

frame `extract_frame': count if missing(__event_date)
local invalid_event_dates = r(N)
if `invalid_event_dates' > 0 {
    display as error ///
        "The extract contains `invalid_event_dates' rows without a valid event date."
    exit 459
}

frame `extract_frame': assert inrange(__event_date, ///
    daily("`start_date'", "YMD"), ///
    daily("`end_date'", "YMD"))
frame `extract_frame': drop __event_date

frame `extract_frame': compress
frame `extract_frame': label data ///
    "BNR CVD private raw REDCap extract through `end_date'"
frame `extract_frame': notes _dta: confidential: Contains identifiable patient-level information
frame `extract_frame': notes _dta: source: BNR CVD REDCap API
frame `extract_frame': notes _dta: event date range: `start_date' through `end_date'
frame `extract_frame': notes _dta: do not place this dataset in the Git repository

frame `extract_frame': save "`outdta'"
frame `extract_frame': count
local extract_rows = r(N)
frame drop `extract_frame'

* -----------------------------------------------------------------------------
* 5. Single operational run summary
* -----------------------------------------------------------------------------
* Keep the end-of-run result tidy in both the Results window and private log.
* A temporary frame is used so the analyst's active data remain untouched.
local extract_rows_display : display %12.0fc `extract_rows'
tempname summary_frame
frame create `summary_frame'

frame `summary_frame': quietly set obs 9
frame `summary_frame': generate str24 operational_item = ""
frame `summary_frame': generate strL result = ""

frame `summary_frame': replace operational_item = "Run status" in 1
frame `summary_frame': replace result = "Completed successfully" in 1
frame `summary_frame': replace operational_item = "Release" in 2
frame `summary_frame': replace result = "`year4'-`month2'" in 2
frame `summary_frame': replace operational_item = "Coverage" in 3
frame `summary_frame': replace result = "`start_date' through `end_date'" in 3
frame `summary_frame': replace operational_item = "Records extracted" in 4
frame `summary_frame': replace result = "`extract_rows_display'" in 4
frame `summary_frame': replace operational_item = "CSV extract" in 5
frame `summary_frame': replace result = `"`outcsv'"' in 5
frame `summary_frame': replace operational_item = "Stata dataset" in 6
frame `summary_frame': replace result = `"`outdta'"' in 6
frame `summary_frame': replace operational_item = "YAML receipt" in 7
frame `summary_frame': replace result = `"`outmanifest'"' in 7
frame `summary_frame': replace operational_item = "Private log" in 8
frame `summary_frame': replace result = `"`outlog'"' in 8
frame `summary_frame': replace operational_item = "Next step" in 9
frame `summary_frame': replace result = ///
    "Join this snapshot to the frozen 2009-2023 dataset (Step 2)." in 9

frame `summary_frame': label variable operational_item "Operational item"
frame `summary_frame': label variable result "Result"
frame `summary_frame': format operational_item %-24s
frame `summary_frame': format result %-180s

local original_linesize = c(linesize)
set linesize 220
display as text ""
display as text "BNR REDCap extraction: operational run summary"
frame `summary_frame': list operational_item result, noobs clean abbreviate(24)
set linesize `original_linesize'

frame drop `summary_frame'

log close redcap_extract
